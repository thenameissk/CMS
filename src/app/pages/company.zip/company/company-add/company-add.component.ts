import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-add',
  templateUrl: './company-add.component.html',
  styleUrls: ['./company-add.component.scss']
})
export class CompanyAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
